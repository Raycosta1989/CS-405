// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>   // for standard exceptions
#include <exception>   // base class
#include <string>

using namespace std;

// Custom exception derived from std::exception
class BankingException : public std::exception {
private:
    string message;
public:
    explicit BankingException(const string& msg) : message(msg) {}
    const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic()
{
    // Throw any standard exception
    throw std::runtime_error("Runtime error in do_even_more_custom_application_logic");

    cout << "Running Even More Custom Application Logic." << endl;
    return true;
}

void do_custom_application_logic()
{
    cout << "Running Custom Application Logic." << endl;

    try {
        if (do_even_more_custom_application_logic()) {
            cout << "Even More Custom Application Logic Succeeded." << endl;
        }
    }
    catch (const std::exception& e) {
        // Catch std::exception and display message
        cout << "Caught standard exception in do_custom_application_logic: " << e.what() << endl;
    }

    // Throw a custom exception derived from std::exception
    throw BankingException("Custom BankingException thrown in do_custom_application_logic");

    cout << "Leaving Custom Application Logic." << endl;
}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero error");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        cout << "divide(" << numerator << ", " << denominator << ") = " << result << endl;
    }
    catch (const std::invalid_argument& e) {
        // Capture ONLY the exception thrown by divide
        cout << "Caught invalid_argument in do_division: " << e.what() << endl;
    }
}

int main()
{
    cout << "Exceptions Tests!" << endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const BankingException& e) {
        // Catch custom exception first
        cout << "Caught custom BankingException in main: " << e.what() << endl;
    }
    catch (const std::exception& e) {
        // Catch standard exceptions
        cout << "Caught std::exception in main: " << e.what() << endl;
    }
    catch (...) {
        // Catch-all handler for uncaught exceptions
        cout << "Caught unknown exception in main." << endl;
    }

    cout << "Program continues after exception handling." << endl;
    return 0;
}